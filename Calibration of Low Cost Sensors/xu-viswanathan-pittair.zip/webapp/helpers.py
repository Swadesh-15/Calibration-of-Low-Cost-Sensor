from datetime import datetime
from pytz import timezone
import time

def format_date(seconds):
    """Convert Epoch date to y/m/d h:m:s in EST"""

    ftime = datetime.fromtimestamp(seconds)
    ftime = ftime.astimezone(timezone("US/Eastern"))
    return ftime.strftime("%d/%m/%Y %H:%M:%S")