# PittAir

Benchmarking Low-cost Air Quality (PM2.5) Sensors-Examining Their Potential to Complement Existing Pollution-Measurement Frameworks in Pittsburgh

## Deployment

Run the PittAir web application using the following commands

```bash
export FLASK_APP=application.py
export DATABASE_URL=<insert URL to database here>
flask run
```

## Contributors
Amy Babay, Abhishek Viswanathan, Vasco Xu
