import os

from datetime import datetime, time
from pytz import timezone
from flask import Flask, flash, jsonify, request, redirect, session, render_template, url_for, send_file
from flask_session import Session
from concurrent.futures import as_completed
from datetime import datetime
from requests_futures.sessions import FuturesSession
from werkzeug.exceptions import default_exceptions
from tempfile import mkdtemp
import json
import urllib

from sqlalchemy import create_engine, engine
from sqlalchemy.orm import scoped_session, sessionmaker

from database import insert

from helpers import format_date


# Configure application
app = Flask(__name__)

# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_FILE_DIR"] = mkdtemp()
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure PostgreSQL database (hosted on Heroku)
engine = create_engine(os.environ['DATABASE_URL'])
db = scoped_session(sessionmaker(bind=engine))

# Create tables (if they don't already exist)
@app.before_first_request
def create_tables():
    with engine.connect() as conn:        
        conn.execute(
            "CREATE TABLE IF NOT EXISTS devices "
            "(id SERIAL, "
            "device_id VARCHAR PRIMARY KEY NOT NULL," 
            "lng VARCHAR NOT NULL, "
            "lat VARCHAR NOT NULL);"
        )

        conn.execute(
            "CREATE TABLE IF NOT EXISTS pittair "
            "(id SERIAL PRIMARY KEY, "
            "device_id VARCHAR REFERENCES devices NOT NULL," 
            "time_cast VARCHAR NOT NULL, "
            "pm3 VARCHAR NOT NULL, "
            "pm5 VARCHAR NOT NULL, "
            "pm10 VARCHAR NOT NULL, "
            "pm25 VARCHAR NOT NULL, "
            "pm100 VARCHAR NOT NULL);"
        )

        conn.execute(
            "CREATE TABLE IF NOT EXISTS purpleair "
            "(id SERIAL PRIMARY KEY, "
            "device_id VARCHAR NOT NULL, "
            "lat VARCHAR NOT NULL, "
            "lng VARCHAR NOT NULL, "
            "time_cast VARCHAR NOT NULL, "
            "pm25 VARCHAR NOT NULL); "
        )

    
# Index route, return home page
@app.route('/')
def index():
    """Render Map"""
    return render_template("map.html")


# Success page
@app.route('/success')
def success():
    """Success"""
    return render_template("success.html")


# Display map
@app.route('/map')
def map():
    """Map"""
    return render_template("map.html")


# Display register form
@app.route('/register', methods=['GET', 'POST'])
def register():
    """Register"""

    if request.method == 'GET':
        return render_template("register.html")

    if request.method == 'POST':
        # Ensure parameters are present
        if not request.form.get("device_id"):
            flash('missing device_id', category="alert-danger")
            return render_template("register.html")
        if not request.form.get("lng"):
            flash('missing device_id', category="alert-danger")
            return render_template("register.html")
        if not request.form.get("lat"):
            flash('missing device_id', category="alert-danger")
            return render_template("register.html")

        # TODO: Validate (lat, lng)
        device_id = request.form.get("device_id")
        lng = request.form.get("lng")
        lat = request.form.get("lat")

        # Store device information in database
        db.execute("INSERT INTO devices (device_id, lat, lng)"
                    "VALUES (:device_id, :lat, :lng)",
                    {"device_id": device_id, 
                    "lat": lat,
                    "lng": lng
                    })
        db.commit()

        flash("You successfully registered a device", category="alert-primary")
        return render_template("register.html")


# Store readings sent by device
@app.route('/readings', methods=['GET', 'POST'])
def readings():
    """Store readings sent by devices in database"""

    if request.method == 'GET':
        readings = db.execute("SELECT * FROM pittair ORDER BY TIME_CAST DESC LIMIT 50").fetchall()
        return render_template("readings.html", readings=readings)
    
    if request.method == 'POST':
        # Retrieve JSON object sent by the device
        content = request.get_json()
        device_id = content["device_id"]
        pm3 = content["pm3"]
        pm5 = content["pm5"]
        pm10 = content["pm10"]
        pm25 = content["pm25"]
        pm100 = content["pm100"]

        # Get current time
        tz = timezone("US/Eastern")
        curr_time = datetime.now(tz)
        time_cast = curr_time.strftime("%d/%m/%Y %H:%M:%S")

        # Store device PittAir reading in database
        db.execute("INSERT INTO pittair (device_id, time_cast, pm3, pm5, pm10, pm25, pm100)"
                    "VALUES (:device_id, :time_cast, :pm3, :pm5, :pm10, :pm25, :pm100)",
                    {"device_id": device_id, 
                    "time_cast": time_cast,
                    "pm3": pm3, 
                    "pm5": pm5,
                    "pm10": pm10,
                    "pm25": pm25,
                    "pm100": pm100
                    })

        # Fetch PurpleAir data (near PittAir device)
        url = 'https://www.purpleair.com/json?key=XP6JMKGYT39ON6F6&show=9896'
        with urllib.request.urlopen(url) as url:
            encoding = url.info().get_content_charset('utf-8')
            response = json.loads(url.read().decode(encoding))
            data = response["results"][0]
            device_id = data["Label"]
            lat = data["Lat"]
            lng = data["Lon"]
            pm25 = data["PM2_5Value"]

            # Store PurpleAir reading in database
            db.execute("INSERT INTO purpleair (device_id, lat, lng, time_cast, pm25)"
                        "VALUES (:device_id, :lat, :lng, :time_cast, :pm25)",
                        {"device_id": device_id, 
                        "lat": lat,
                        "lng": lng,
                        "time_cast": time_cast,
                        "pm25": pm25
                        })

        db.commit()

        return "Readings added to the database\n"


# Fetch sensor locations
@app.route('/sensors')
def sensors():
    url = 'https://data.wprdc.org/api/3/action/datastore_search?resource_id=b646336a-deb4-4075-aee4-c5d28d88c426&limit=14'
    with urllib.request.urlopen(url) as url:
        encoding = url.info().get_content_charset('utf-8')
        data = url.read().decode(encoding)
        return jsonify(data)
    
    return None


# Fetch air quality data
@app.route('/airdata')
def airdata():
    name = urllib.parse.quote(request.args.get("name").strip())
    url = 'https://data.wprdc.org/api/3/action/datastore_search_sql?sql=SELECT%20*%20from%20%2215d7dbf6-cb3b-407b-ae01-325352deed5c%22%20WHERE%20site%20=%20%27' + name + '%27%20AND%20int_t%20IS%20NOT%20NULL%20ORDER%20BY%20_id%20DESC%20LIMIT%203'
    with urllib.request.urlopen(url) as url:
        encoding = url.info().get_content_charset('utf-8')
        data = url.read().decode(encoding)
        return jsonify(data)
    
    return None


# Fetch SmellPGH data
@app.route('/smell')
def smell():
    start_time = int(datetime.combine(datetime.today(), time.min).timestamp()) # Last midnight
    params = {'start_time': start_time, 'format': 'json'}
    url = '{}?{}'.format('https://api.smellpittsburgh.org/api/v2/smell_reports', urllib.parse.urlencode(params))
    with urllib.request.urlopen(url) as url:
        encoding = url.info().get_content_charset('utf-8')
        data = url.read().decode(encoding)
        return jsonify(data)
    
    return None


# Fetch PurpleAir data (for manually selected sensors)
@app.route('/purpleair', methods=['GET', 'POST'])
def purpleair():
    if request.method == 'GET':
        urls = [
            'https://www.purpleair.com/json?key=KQZUEM5GA3IW13B1&show=34121', # Pitt Economics Department
            'https://www.purpleair.com/json?key=OTTGHBZTT6EP7T3M&show=29893', # Pitt PEEL Lab
            'https://www.purpleair.com/json?key=OTTGHBZTT6EP7T3M&show=29893', # CMU CREATE Lab 1
            'https://www.purpleair.com/json?key=6KHEQU9S8LK082E0&show=9642',  # CMU CREATE Lab 2
            'https://www.purpleair.com/json?key=9P056HC2VFJ99AP0&show=9644',  # CMU CREATE Lab 3
            'https://www.purpleair.com/json?key=SMZKOU2FZSJ012MV&show=21277', # 3339 Penn Ave
            'https://www.purpleair.com/json?key=51RAL1UP8L0U8HOQ&show=27683', # CAZIER-PA-001
            'https://www.purpleair.com/json?key=YJEJOEW61K4GXCFV&show=27637', # CAZIER-PA-004
            'https://www.purpleair.com/json?key=08ZWQK5LTMF51LHP&show=27577', # CAZIER-PA-007
            'https://www.purpleair.com/json?key=Y5O1FNSNUZ7OF96B&show=27583', # CAZIER-PA-011
            'https://www.purpleair.com/json?key=CF5J1J8K8RPWUFZ5&show=27673', # CAZIER-PA-019
            'https://www.purpleair.com/json?key=B5MOIKHPA7HCYKUC&show=27765', # CaZIER-PA-026
            'https://www.purpleair.com/json?key=OJFUTLN85JMR8LRN&show=9038',  # Pillars in Squirrel Hill North
            'https://www.purpleair.com/json?key=XP6JMKGYT39ON6F6&show=9896', # EastEndAve1
        ]

        # Send multi-threaded request to PurpleAir
        responses = []
        with FuturesSession() as session:
            futures = [session.get(url) for url in urls]
            for future in as_completed(futures):
                response = future.result()
                if (response.content is not None): 
                    data = json.loads(response.content)
                    responses.append(data)
        
        return jsonify(responses)
        

# Fetch PittAPI data
@app.route('/pittair')
def pittair():
    query = "SELECT * FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY pittair.device_id "\
            "ORDER BY TO_TIMESTAMP(time_cast, 'DD/MM/YYYY HH24:MI:SS') DESC) AS rownum, "\
            "pittair.* FROM pittair INNER JOIN devices ON pittair.device_id = devices.device_id"\
            ") tmp WHERE tmp.rownum = 1"
    rows = db.execute(query).fetchall()
    return jsonify([dict(i) for i in rows])


# Fetch Google Maps marker icon
@app.route('/marker')
def marker():
    markers = {
        'blue': 'static/blue_marker.png',
        'purple': 'static/purple_marker.png',
        'red': 'static/red_marker.png',
        'yellow': 'static/yellow_marker.png'
    }
    color = request.args.get('color')
    return send_file(markers[color], mimetype='image/png')


# Handle errors
def errorhandler(error):
    """Handle Error"""
    return error


# Listen for errors
for code in default_exceptions:
   app.errorhandler(code)(errorhandler)