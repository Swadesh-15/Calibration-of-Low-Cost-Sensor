// Google Map
let map;

// Markers for map
let markers = [];

// Info window
let info = new google.maps.InfoWindow();


// Execute when the DOM is fully loaded
$(document).ready(function() {

    // Query Allengheny County sensor locations
    $.ajax({
        url: '/sensors',
        dataType: 'json',
        success: function(data) {
            var jsonData = JSON.parse(data);
            var locData = Object.values(jsonData.result.records);
            for (let i = 0; i < locData.length; i++) {
                var lat = parseFloat(locData[i]["latitude"]);
                var lng = parseFloat(locData[i]["longitude"]);
                var name = locData[i]["site"];
                
                // Place location marker on the map
                var place = {
                    type: "allegheny",
                    latitude: lat,
                    longitude: lng, 
                    name: name
                };
                addMarker(place);
            }
        }
    });

    // Query SmellPGH API
    $.ajax({
        url: '/smell',
        dataType: 'json',
        success: function(data) {
            var smellData = JSON.parse(data);
            for (let i = 0; i < smellData.length; i++) {
                var lat = parseFloat(smellData[i]["latitude"]);
                var lng = parseFloat(smellData[i]["longitude"]);
                var smell_value = smellData[i]["smell_value"];
                var smell_description = smellData[i]["smell_description"];
                var observed_at = smellData[i]["observed_at"];
                
                // Place location marker on the map
                var place = {
                    type: "smellPGH",
                    latitude: lat,
                    longitude: lng,
                    smell_value: smell_value,
                    small_description: smell_description,
                    observed_at: observed_at
                };
                addMarker(place);
            }
        }
    });

    // Query PurpleAir API
    $.ajax({
        url: '/purpleair',
        dataType: 'json',
        success: function(data) {
            for (let i = 0; i < data.length; i++) {
                var purpleData = data[i].results;
                if (!purpleData) continue;
                var lat = parseFloat(purpleData[0]["Lat"]);
                var lng = parseFloat(purpleData[0]["Lon"]);
                var name = purpleData[0]["Label"];
                var pm_value = purpleData[0]["PM2_5Value"];
                var humidity = purpleData[0]["humidity"];
                var last_seen = purpleData[0]["LastSeen"];
                                
                // Place location marker on the map
                var place = {
                    type: "purpleair",
                    latitude: lat,
                    longitude: lng,
                    name: name,
                    pm_value: pm_value,
                    humidity: humidity,
                    last_seen: last_seen
                };
                addMarker(place);
            }
        }
    });

    // Query PittAPI
    $.ajax({
        url: '/pittair',
        dataType: 'json',
        success: function(data) {
            for (let i = 0; i < data.length; i++) {
                var pittData = data[i];
                /*
                pm3 = pittData["pm3"]
                pm5 = pittData["pm5"]
                pm10 = pittData["pm10"]
                pm25 = pittData["pm25"]
                pm100 = pittData["pm100"]
                temp = pittData["temp"]
                hum = pittData["hum"]
                */
                lat = parseFloat(pittData["lat"])
                lng = parseFloat(pittData["lng"])
                                
                // Place location marker on the map
                var place = {
                    type: "pittair",
                    data: pittData,
                    latitude: lat,
                    longitude: lng
                };
                addMarker(place);
            }
        }
    });   

    // Styles for map
    // https://developers.google.com/maps/documentation/javascript/styling
    let styles = [

        // Hide/Show Google's labels
        {
            featureType: "all",
            elementType: "labels",
            stylers: [
                {visibility: "on"}
            ]
        },

        // Hide roads
        {
            featureType: "road",
            elementType: "geometry",
            stylers: [
                {visibility: "off"}
            ]
        }
    ];

    // Options for map
    // https://developers.google.com/maps/documentation/javascript/reference#MapOptions
    let options = {
        center: {lat: 40.4406, lng: -79.9959}, // Pittsburgh, PA
        disableDefaultUI: true,
        mapTypeId: google.maps.MapTypeId.ROADMAP,
        maxZoom: 14,
        panControl: true,
        styles: styles,
        zoom: 13,
        zoomControl: true
    };

    // Get DOM node in which map will be instantiated
    let canvas = $("#map-canvas").get(0);

    // Instantiate map
    map = new google.maps.Map(canvas, options);

    // Configure UI once Google Map is idle (i.e., loaded)
    google.maps.event.addListenerOnce(map, "idle", configure);

});


// Add marker for place to map
function addMarker(place)
{
    // Get coordinates for marker
    let myLatLng = {lat: place.latitude, lng: place.longitude};

    // Get marker for dataset
    let markerColor = {
        allegheny: 'red',
        smellPGH: 'yellow',
        purpleair: 'purple',
        pittair: 'blue'
    }

    // Configure image for marker
    var image = {
        url: '/marker?color=' + markerColor[place.type],
        scaledSize: new google.maps.Size(22, 40),
        origin: new google.maps.Point(0, 0),
        anchor: new google.maps.Point(0, 40),
        labelOrigin: new google.maps.Point(0, 52)
    };

    // Set marker
    let marker = new google.maps.Marker({
        position: myLatLng,
        icon: image,
        map: map
    });
    marker.setMap(map);
    
    marker.addListener("click", function() {
        // Query readings for Allegheny County
        if (place.type == "allegheny") {
            // Title
            title = "<p class='text-center'><b>" + place.name+ "</b></p>";
            title += "<div class='text-center'>" + todaysDate() + "</div>";

            // Query Allegheny County air data (for each sensor location)
            $.ajax({
                url: "/airdata",
                data: {name: place.name},
                dataType: 'json',
                success: function(data) {
                    var jsonData = JSON.parse(data);
                    var airData = Object.values(jsonData.result.records);

                    // Start list
                    ul = "<ul class='list-group list-group-horizontal'>";
                    for (let i = 0; i < airData.length; i++)
                    {
                        // Format date into HH:MM
                        var date = new Date(airData[i]["datetime"]);
                        date = date.toLocaleTimeString('pt-PT').split(":");
                        date = date[0] + ":" + date[1];

                        var pm = "<b>" + airData[i]["int_t"] + "</b>";

                        item = "<li class='list-group-item no-vertical-border flex-fill text-center pm-readings'>" + date + "<br/>" + pm + "</li>";                        
                        ul += item;
                    }
                    // End list
                    ul += "</ul>";
        
                    // Complete info
                    myInfo = title + ul;
        
                    // Create info window
                    showInfo(marker, myInfo);
                }
            });
        }
        
        // Display SmellPGH data
        if (place.type == "smellPGH") {
            var myInfo = "<div class='text-center'><b>Smell Pittsburgh</b></div>";

            // Convert epoch time to date
            var date = new Date(0);
            date.setUTCSeconds(place.observed_at);
            date = formatDate(date);

            myInfo += "<hr class='divider'/>"
            myInfo += "<div><b>Smell Rating: </b>" + place.smell_value + "</div>";
            myInfo += "<div><b>Description: </b>" + place.smell_description + "</div>";
            myInfo += "<div><b>Date: </b>" + date + "</div>";

            // Create info window
            showInfo(marker, myInfo);
        }

        // Display PurpleAir data
        if (place.type == "purpleair") {
            var myInfo = "<div class='text-center'><b>Purple Air</b></div>";

            // Convert epoch time to date
            var date = new Date(0);
            date.setUTCSeconds(place.last_seen);
            date = formatDate(date);

            myInfo += "<hr class='divider'/>"
            myInfo += "<div><b>Name: </b>" + place.name + "</div>";
            myInfo += "<div><b>PM2.5: </b>" + place.pm_value + "</div>";
            myInfo += "<div><b>Humidity: </b>" + place.humidity + "</div>";
            myInfo += "<div><b>Date: </b>" + date + "</div>";

            // Create info window
            showInfo(marker, myInfo);
        }

        // Display PittAir data
        if (place.type == "pittair") {
            var myInfo = "<div class='text-center'><b>PittAir</b></div>";

            myInfo += "<hr class='divider'/>"
            myInfo += "<div><b>Name: </b>" + place.data["device_id"] + "</div>";
            myInfo += "<div><b>PM3: </b>" + place.data["pm3"] + "</div>";
            myInfo += "<div><b>PM5: </b>" + place.data["pm5"] + "</div>";
            myInfo += "<div><b>PM10: </b>" + place.data["pm10"] + "</div>";
            myInfo += "<div><b>PM25: </b>" + place.data["pm25"] + "</div>";
            myInfo += "<div><b>PM100: </b>" + place.data["pm100"] + "</div>";
            myInfo += "<div><b>Temperature: </b>" + place.data["temp"] + "</div>";
            myInfo += "<div><b>Humidity: </b>" + place.data["hum"] + "</div>";
            myInfo += "<div><b>Date: </b>" + place.data["time_cast"] + "</div>";

            // Create info window
            showInfo(marker, myInfo);
        }
     });

    // Insert marker into global markers array
    markers.push(marker);
}


// Configure application
function configure()
{
    // Update UI after map has been dragged
    google.maps.event.addListener(map, "dragend", function() {

        // If info window isn't open
        // http://stackoverflow.com/a/12410385
        if (!info.getMap || !info.getMap())
        {
            update();
        }
    });

    // Update UI after zoom level changes
    google.maps.event.addListener(map, "zoom_changed", function() {
        update();
    });

    // Update UI
    update();
}


// Remove markers from map
function removeMarkers()
{
    // Remove markers
    for (let i = 0; i < markers.length; i++)
    {
        markers[i].setMap(null);
    }

    // Remove references to the markers
    markers.length = 0;
}


// Show info window at marker with content
function showInfo(marker, content)
{
    // Start div
    let div = "<div id='info'>";
    if (typeof(content) == "undefined")
    {
        // http://www.ajaxload.info/
        div += "<img alt='loading' src='/static/ajax-loader.gif'/>";
    }
    else
    {
        div += content;
    }

    // End div
    div += "</div>";

    // Set info window's content
    info.setContent(div);

    // Open info window (if not already open)
    info.open(map, marker);
}


// Update UI's markers
function update()
{
    /*
    $.getJSON("/update", parameters, function(data, textStatus, jqXHR) {

       // Remove old markers from map
       removeMarkers();

       // Add new markers to map
       for (let i = 0; i < data.length; i++)
       {
           addMarker(data[i]);
       }
    });
    */
};


// Format date to MONTH DAY, YEAR
function formatDate(date)
{
    const monthNames = [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ];
    let month = monthNames[date.getMonth()];
    let day = String(date.getDate()).padStart(2, '0');
    let year = date.getFullYear();
    return month + " " + day  + ',' + " " + year;
}


// Obtain today's date
function todaysDate()
{
    let date = new Date();
    return formatDate(date);
}