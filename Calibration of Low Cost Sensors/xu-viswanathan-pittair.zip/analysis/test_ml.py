import pandas as pd
import numpy as np
import pickle
import matplotlib.pyplot as plt 
import urllib.request
import json
from datetime import datetime
from sklearn import metrics
from sklearn.model_selection import train_test_split 

"""
# Fetch PurpleAir data (near PittAir device)
purpleair = {'time_cast': [], 'pm25': [], 'temp': [], 'hum': []}
url = 'https://api.thingspeak.com/channels/982481/feeds.json?api_key=MZ34CXKNLEQMIL07&results=8000&start=2020-04-14%2000:00:00&timezone=America/New_York'
with urllib.request.urlopen(url) as url:
    encoding = url.info().get_content_charset('utf-8')
    response = json.loads(url.read().decode(encoding))
    data = response["feeds"]
    for feed in data:
        # Format date
        date = feed["created_at"]
        date = date[:-6]
        date = datetime.strptime(date, "%Y-%m-%dT%H:%M:%S")
        date = date.strftime("%d/%m/%Y %H:%M")

        pm25 = feed["field2"]
        temp = feed["field6"]
        hum = feed["field7"]

        purpleair['time_cast'].append(date)
        purpleair['pm25'].append(pm25)
        purpleair['temp'].append(temp)
        purpleair['hum'].append(hum)
    
df = pd.DataFrame(purpleair, columns=['time_cast', 'pm25', 'temp', 'hum'])
df.to_csv('purpleair_cromwell.csv', index=False, header=True)
"""

# Read the CSVs
master = pd.read_csv('datasets/master_dataset.csv')
x = np.array(master['m_pm25']).reshape(-1, 1)[1023:1935]
y = np.array(master['pu1_pm25_sorted']).reshape(-1, 1)[1023:1935].ravel()

# Load the ML model
model = pickle.load(open('077model.sav', 'rb'))
result = model.score(x, y)
pred = np.array(model.predict(x))

# Print statistics
print('Mean Absolute Error:', metrics.mean_absolute_error(y, pred))
print('Mean Squared Error:', metrics.mean_squared_error(y, pred))
print('Root Mean Squared Error:', np.sqrt(metrics.mean_squared_error(y, x)))

# Convert original PittAir data to Pandas DataFrame
pittair = {'time_cast': master['m_time_cast'][1023:1935], 'pm25': master['m_pm25'][1023:1935]}
pittair = pd.DataFrame.from_dict(pittair)

# Convert TestPurpleAir data to Pandas DataFrame
purpleair = {'time_cast': master['m_time_cast'][1023:1935], 'pm25': master['pu1_pm25_sorted'][1023:1935]}
purpleair = pd.DataFrame.from_dict(purpleair)

# Convert Predictions data to Pandas DataFrame
prediction = {'time_cast': master['m_time_cast'][1023:1935], 'pm25': pred}
prediction = pd.DataFrame.from_dict(prediction)

# Print Actual and Predicted values
df = pd.DataFrame({'Actual': y.flatten(), 'Predicted': pred.flatten()})
df.to_csv('actualvspred.csv', index=False, header=True)

# Plot the predictions
ax = pittair.plot(x='time_cast', y='pm25', style='o')
purpleair.plot(ax=ax, x='time_cast', y='pm25', style='o')
legend = plt.legend()
legend.get_texts()[0].set_text('PittAir (Maple)')
legend.get_texts()[1].set_text('PurpleAir')
plt.title('PittAir (Maple) vs PurpleAir')
plt.xlabel('Time')
plt.ylabel('PM2.5')
plt.show()