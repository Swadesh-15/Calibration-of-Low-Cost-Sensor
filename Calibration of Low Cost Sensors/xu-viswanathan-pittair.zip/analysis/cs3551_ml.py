import numpy as np 
import pandas as pd 
import seaborn as sns
import pickle
import matplotlib.pyplot as plt 
from sklearn import preprocessing, svm
from sklearn.model_selection import train_test_split 
from sklearn.linear_model import LinearRegression
from scipy.signal import savgol_filter

from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import classification_report,confusion_matrix
from sklearn import metrics

from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import LassoCV
from sklearn.pipeline import make_pipeline
from sklearn.ensemble import RandomForestRegressor


# Read dataset
master = pd.read_csv('datasets/master-indoors_train.csv')

# Plot the datasets
ax = master.plot(x='m_time_cast', y='m_pm25', style='o')
master.plot(ax=ax, x='m_time_cast', y='pu_pm25_sorted', style='o')
legend = plt.legend()
legend.get_texts()[0].set_text('PittAir (Maple)')
legend.get_texts()[1].set_text('PurpleAir')
plt.title('PittAir (Maple) vs PurpleAir')
plt.xlabel('Time')
plt.ylabel('PM2.5')
plt.show()

# Split the data into training/testing sets
x = np.array(master['m_pm25']).reshape(-1, 1)[:1022]
y = np.array(master['pu_pm25_sorted']).reshape(-1, 1)[:1022].ravel()
print('Root Mean Squared Error:', np.sqrt(metrics.mean_squared_error(y, x)))
X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.25)

# Neural Network
"""
mlp = MLPClassifier(hidden_layer_sizes=(10, 10, 10))
mlp.fit(X_train, y_train)

predictions = mlp.predict(X_test)
print(classification_report(y_test, predictions))
"""

"""
# Linear Regression
model = LinearRegression()
model.fit(X_train, y_train)
y_pred = regr.predict(X_test) 
plt.scatter(X_test, Y_test, color ='b') 
plt.plot(X_test, y_pred, color ='k') 
plt.show()
"""

# Random Forest
"""
model = RandomForestRegressor(n_estimators = 100)
model.fit(X_train, y_train)
test_score = model.score(X_test, y_test)
print('accuracy (rf): ', test_score)
# pickle.dump(model, open('model.sav', 'wb'))
"""

"""
# Alpha (regularization strength) of LASSO regression
lasso_eps = 0.01
lasso_nalpha = 20
lasso_iter = 10e5
lasso_tol = 12

# Min and max degree of polynomials features to consider
degree_min = 2
degree_max = 15
# Make a pipeline model with polynomial transformation and LASSO regression with cross-validation, run it for increasing degree of polynomial (complexity of the model
for degree in range(degree_min,degree_max+1):
    model = make_pipeline(PolynomialFeatures(degree, interaction_only=False), LassoCV(eps=lasso_eps, n_alphas=lasso_nalpha, max_iter=lasso_iter, tol=lasso_tol,
normalize=True,cv=5))
    model.fit(X_train, y_train)
    test_pred = np.array(model.predict(X_test))
    # Plot the curve
    plt.scatter(X_test, y_test, color ='b') 
    plt.plot(X_test, test_pred, color ='k') 
    plt.show()
    test_score = model.score(X_test, y_test)
    # Save ML model 
    pickle.dump(model, open('model' + str(degree) + '.sav', 'wb'))
    print('accuracy (' + str(degree) + '): ', test_score)
"""