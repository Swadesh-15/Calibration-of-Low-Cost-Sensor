# Analysis

Analysis of data collected from PittAir sensors.

# Files

test_ml.py - python script used for testing the ML model (also graphs the results).
cs3551_ml.py - python script used for training a model (also graphs the results).
077mode.sav - a ML model (trained with Random Forest Regression) with 77% accuracy.
datasets - a folder containing the datasets used for training and testing (the master_dataset.csv contains all used values).
graphs - a folder containing graphs produced from the collected data.
ML-predictions - a folder containing Jupyter Notebooks files.

## Contributors
Amy Babay, Abhishek Viswanathan, Vasco Xu
